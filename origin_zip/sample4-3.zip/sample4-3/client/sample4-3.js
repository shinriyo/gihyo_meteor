Template.mainContent.yourName = "白石";
Template.mainContent.now = new Date;
