// 変数yourNameに対応する定数
Template.mainContent.yourName = function() {
    return "白石";
};
// 変数nowに対応する定数
Template.mainContent.now = function() {
    return new Date;
};
