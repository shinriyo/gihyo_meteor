window.onload = function() {
    var button = document.getElementById('button');
    button.addEventListener('click', function() {
        hello();
    }, false);
};
