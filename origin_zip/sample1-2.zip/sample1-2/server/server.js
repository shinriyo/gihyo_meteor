Meteor.startup(function () {
    hello();
});
